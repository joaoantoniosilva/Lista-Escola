package com.example.demo;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.RETURNS_DEFAULTS;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.model;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;

import org.hamcrest.Matchers;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import com.example.demo.controller.TurmaController;
import com.example.demo.model.Turma;
import com.example.demo.repositpry.TurmaRepository;

@SpringBootTest
@AutoConfigureMockMvc
//@WebMvcTest(TurmaController.class)
public class TestRepository {

	class DashboardControllerTest {
		@Autowired
		private MockMvc mockMvc;
		@MockBean
		private TurmaRepository dashboardService;

	@Test
	void shouldReturnViewWithPrefilledData() throws Exception {
	when(dashboardService.findById((long) 1)).equals(dashboardService);
	this.mockMvc
	.perform(get("/dashboard"))
	.andExpect(status().isOk())
	.andExpect(view().name("dashboard"))
	.andExpect(model().attribute("user", "Duke"))
	.andExpect(model().attribute("analyticsGraph", Matchers.arrayContaining(13, 42)))
	.andExpect(model().attributeExists("quickNote"));
	}
	}
}