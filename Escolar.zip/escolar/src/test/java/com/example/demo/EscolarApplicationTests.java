package com.example.demo;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.web.servlet.ModelAndView;

import com.example.demo.controller.TurmaController;
import com.example.demo.model.Turma;
import com.example.demo.repositpry.TurmaRepository;

@SpringBootTest
@AutoConfigureMockMvc
class EscolarApplicationTests {
	 @Autowired
	    private MockMvc mockMvc;

	    @Mock
	    private TurmaRepository turmaRepository;

	    @InjectMocks
	    private TurmaController turmaController;
	  
	    //private Turma turma;
	    
	    // teste findAll
	    @Test
	    public void testFindAll() throws Exception {
	    	// Criação de produtos simulados
	    	List<Turma> turmaTest = new ArrayList<>();
	    	turmaTest.add(new Turma((long)52, "AD", 33));
	    	turmaTest.add(new Turma((long)102, "Turma 3", 40));


	    	
	    	 // Chamada do endpoint
	    	 MvcResult mvcResult = mockMvc.perform(MockMvcRequestBuilders.get("/turma/lista")//.contentType(MediaType.APPLICATION_JSON)
	                 )
	         		
	                 .andExpect(MockMvcResultMatchers.status().isOk())
	                 .andReturn();
	    	
	    	 ModelAndView modelAndView = mvcResult.getModelAndView();
	    	   	  
	    	  List<Turma> mensagem =  (List<Turma>) modelAndView.getModel().get("turmas");

	    	  
	        // Verificando se todos os produtos foram retornados corretamente
	    	  
	        assertEquals(turmaTest.size(), mensagem.size());
	        assertEquals(turmaTest.get(0).getNome(), mensagem.get(0).getNome());
	        assertEquals(turmaTest.get(0).getNumeroAlunos(), mensagem.get(0).getNumeroAlunos());
	    		
	    	
	    }
}
